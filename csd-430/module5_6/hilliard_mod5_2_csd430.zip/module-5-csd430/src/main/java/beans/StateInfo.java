package beans;

import java.io.Serializable;

/**
 * Katie Hilliard
 * CSD430 – Module 5.2 Assignment
 * JavaBean  state data from katie_states_data table.
 */

public class StateInfo implements Serializable {
	private static final long serialVersionUID = 1L;
    private int state_id;
    private String state_name;
    private String capital;
    private double population_millions;
    private String abbreviation;

    public int getState_id() { return state_id; }
    public void setState_id(int state_id) { this.state_id = state_id; }

    public String getState_name() { return state_name; }
    public void setState_name(String state_name) { this.state_name = state_name; }

    public String getCapital() { return capital; }
    public void setCapital(String capital) { this.capital = capital; }

    public double getPopulation_millions() { return population_millions; }
    public void setPopulation_millions(double population_millions) { this.population_millions = population_millions; }

    public String getAbbreviation() { return abbreviation; }
    public void setAbbreviation(String abbreviation) { this.abbreviation = abbreviation; }
}
