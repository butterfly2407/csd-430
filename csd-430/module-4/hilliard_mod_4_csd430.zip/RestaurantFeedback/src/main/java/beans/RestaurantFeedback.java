// RestaurantFeedback.java
// Katie Hilliard
// 06/15/2025
// Module 4 Assignment - JavaBean
// The purpose of this JavaBean is to store the restaurant feedback data in a JSP page

package beans;

import java.io.Serializable;

public class RestaurantFeedback implements Serializable {

    private static final long serialVersionUID = 1L;

    // Instance variables

    private String customerName;         // Customer's first and last name
    private String visitDate;            // Date customer visited the restaurant
    private String foodQuality;          // Customer's food quality rating
    private String serviceRating;        // Customer's service quality rating
    private String additionalComments;   // Customer can add comments if necessary

    // Constructor
    public RestaurantFeedback() {}

    // Getter and Setter Methods

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(String visitDate) {
        this.visitDate = visitDate;
    }

    public String getFoodQuality() {
        return foodQuality;
    }

    public void setFoodQuality(String foodQuality) {
        this.foodQuality = foodQuality;
    }

    public String getServiceRating() {
        return serviceRating;
    }

    public void setServiceRating(String serviceRating) {
        this.serviceRating = serviceRating;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }
}

